package com.pb.dto;

import java.sql.Date;


public class DdDetails {

	private int ddnumber;
	private long accNo;
	private String payeeName;
	private Date date;
	private long amt;
	private String status;
	@Override
	public String toString() {
		return "DdDetails [ddnumber=" + ddnumber + ", accNo=" + accNo
				+ ", payeeName=" + payeeName + ", date=" + date + ", amt="
				+ amt + ", status=" + status + "]";
	}
	public DdDetails(int ddnumber, long accNo, String payeeName, Date date,
			long amt, String status) {
		super();
		this.ddnumber = ddnumber;
		this.accNo = accNo;
		this.payeeName = payeeName;
		this.date = date;
		this.amt = amt;
		this.status = status;
	}
	public DdDetails() {
		super();
	}
	public int getDdnumber() {
		return ddnumber;
	}
	public void setDdnumber(int ddnumber) {
		this.ddnumber = ddnumber;
	}
	public long getAccNo() {
		return accNo;
	}
	public void setAccNo(long accNo) {
		this.accNo = accNo;
	}
	public String getPayeeName() {
		return payeeName;
	}
	public void setPayeeName(String payeeName) {
		this.payeeName = payeeName;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
	public long getAmt() {
		return amt;
	}
	public void setAmt(long amt) {
		this.amt = amt;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	
	
	
}
