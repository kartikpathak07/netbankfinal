package com.pb.dto;

public class Information 
{
	private String custname;
	private String address;
	private long contactno;
	private String email;
	public Information(String custname, String address, long contactno,
			String email) {
		super();
		this.custname = custname;
		this.address = address;
		this.contactno = contactno;
		this.email = email;
	}
	public Information() {
		super();
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getContactno() {
		return contactno;
	}
	public void setContactno(long contactno) {
		this.contactno = contactno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	@Override
	public String toString() {
		return "Information [custname=" + custname + ", address=" + address
				+ ", contactno=" + contactno + ", email=" + email + "]";
	}
}
