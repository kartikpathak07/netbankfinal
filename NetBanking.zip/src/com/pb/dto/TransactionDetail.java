package com.pb.dto;

public class TransactionDetail 
{
	private String transactionId;
	private String userName;
	private String beniName;
	private long amount;
	private String transactDate;
	private String month;
	private String transactMode;
	public TransactionDetail(String transactionId, String userName,
			String beniName, long amount, String transactDate, String month,
			String transactMode) {
		super();
		this.transactionId = transactionId;
		this.userName = userName;
		this.beniName = beniName;
		this.amount = amount;
		this.transactDate = transactDate;
		this.month = month;
		this.transactMode = transactMode;
	}
	public TransactionDetail() {
		super();
	}
	public String getTransactionId() {
		return transactionId;
	}
	public void setTransactionId(String transactionId) {
		this.transactionId = transactionId;
	}
	public String getUserName() {
		return userName;
	}
	public void setUserName(String userName) {
		this.userName = userName;
	}
	public String getBeniName() {
		return beniName;
	}
	public void setBeniName(String beniName) {
		this.beniName = beniName;
	}
	public long getAmount() {
		return amount;
	}
	public void setAmount(long amount) {
		this.amount = amount;
	}
	public String getTransactDate() {
		return transactDate;
	}
	public void setTransactDate(String transactDate) {
		this.transactDate = transactDate;
	}
	public String getMonth() {
		return month;
	}
	public void setMonth(String month) {
		this.month = month;
	}
	public String getTransactMode() {
		return transactMode;
	}
	public void setTransactMode(String transactMode) {
		this.transactMode = transactMode;
	}
	@Override
	public String toString() {
		return "TransactionDetail [transactionId=" + transactionId
				+ ", userName=" + userName + ", beniName=" + beniName
				+ ", amount=" + amount + ", transactDate=" + transactDate
				+ ", month=" + month + ", transactMode=" + transactMode + "]";
	}
	
}
