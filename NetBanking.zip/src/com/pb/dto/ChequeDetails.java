package com.pb.dto;

import java.sql.Date;

public class ChequeDetails 
{
	private int chkBookNo;
	private String accNo;
	private String status;
	private Date date;
	@Override
	public String toString() {
		return "ChequeDetails [chkBookNo=" + chkBookNo + ", accNo=" + accNo
				+ ", status=" + status + ", date=" + date + "]";
	}
	public ChequeDetails(int chkBookNo, String accNo, String status, Date date) {
		super();
		this.chkBookNo = chkBookNo;
		this.accNo = accNo;
		this.status = status;
		this.date = date;
	}
	public ChequeDetails() {
		super();
	}
	public int getChkBookNo() {
		return chkBookNo;
	}
	public void setChkBookNo(int chkBookNo) {
		this.chkBookNo = chkBookNo;
	}
	public String getAccNo() {
		return accNo;
	}
	public void setAccNo(String accNo) {
		this.accNo = accNo;
	}
	public String getStatus() {
		return status;
	}
	public void setStatus(String status) {
		this.status = status;
	}
	public Date getDate() {
		return date;
	}
	public void setDate(Date date) {
		this.date = date;
	}
}
