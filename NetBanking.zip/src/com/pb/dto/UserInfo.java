package com.pb.dto;

public class UserInfo 
{
	private long account_no;
	private String username;
	private String custname;
	private long balance;
	private String acctype;
	private String address;
	private long phoneno;
	private String email;
	private String password;
	public UserInfo() {
		super();
	}
	public UserInfo(long account_no, String username, String custname,
			long balance, String acctype, String address, long phoneno,
			String email,String password) {
		super();
		this.account_no = account_no;
		this.username = username;
		this.custname = custname;
		this.balance = balance;
		this.acctype = acctype;
		this.address = address;
		this.phoneno = phoneno;
		this.email = email;
		this.password=password;
	}
	@Override
	public String toString() {
		return "UserInfo [account_no=" + account_no + ", username=" + username
				+ ", custname=" + custname + ", balance=" + balance
				+ ", acctype=" + acctype + ", address=" + address
				+ ", phoneno=" + phoneno + ", email=" + email + ", password="
				+ password + "]";
	}
	public String getPassword() {
		return password;
	}
	public void setPassword(String password) {
		this.password = password;
	}
	public long getAccount_no() {
		return account_no;
	}
	public void setAccount_no(long account_no) {
		this.account_no = account_no;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getCustname() {
		return custname;
	}
	public void setCustname(String custname) {
		this.custname = custname;
	}
	public long getBalance() {
		return balance;
	}
	public void setBalance(long balance) {
		this.balance = balance;
	}
	public String getAcctype() {
		return acctype;
	}
	public void setAcctype(String acctype) {
		this.acctype = acctype;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public long getPhoneno() {
		return phoneno;
	}
	public void setPhoneno(long phoneno) {
		this.phoneno = phoneno;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
}
