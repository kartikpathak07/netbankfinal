package com.pb.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.List;




import com.pb.dto.Beneficiary;
import com.pb.dto.ChequeDetails;
import com.pb.dto.DdDetails;
import com.pb.dto.Details;
import com.pb.dto.TransactionDetail;
import com.pb.util.JdbcConnection;

public class BeneficiaryDaoImpl implements BeneficiaryDao 
{
	
	List ar = new ArrayList();

	public int addBeneficiary(long account_no, String username, int ifsc,
			String benname) 
	{
		int i = 1;
		int rand = (int) (Math.random() * 1000);
		String b_id = "" + rand;
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst1=null;
		
		String query1="SELECT * FROM customer WHERE ACC_NO=?";
		
		try {
			pst1=conn.prepareStatement(query1);
			pst1.setLong(1, account_no);
			int updateCount1 = pst1.executeUpdate();
			
			

			if(updateCount1>0){
			String query = "insert into beneficiary values(?,?,?,?,?,?,?)";
			try {
				PreparedStatement pst = conn.prepareStatement(query);
				pst.setString(1, b_id);
				pst.setLong(2, account_no);
				pst.setString(3, username);
				pst.setInt(4, ifsc);
				pst.setString(5, "inactive");
				pst.setString(6, "no");
				pst.setString(7, benname);
				int updateCount = pst.executeUpdate();
				if (updateCount > 0)
					i = 0;
				else
					i = 1;
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			
			
}
			else{
				System.out.println("Invalid beneficiary account");
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return i;
	}
	
	// View Beneficiary for User method

	public List viewBeneficiary(String username) throws SQLException 
	{

		List<Beneficiary> b = new ArrayList<Beneficiary>();
		Connection conn = null;
		try {
			System.out.println(username);
			conn = JdbcConnection.getConnection();
			String sql = "select * from beneficiary where username=?";
			PreparedStatement pst = conn.prepareStatement(sql);
			pst.setString(1, username);
			ResultSet rs = pst.executeQuery();
			while (rs.next()) {

				System.out.println("Beneficiary View ");
				Beneficiary b1 = new Beneficiary();
				b1.setBid(rs.getString(1));
				b1.setAccount_no(rs.getLong(2));
				b1.setUsername(rs.getString(3));
				b1.setIfsc(rs.getInt(4));
				b1.setActivstat(rs.getString(5));
				b1.setApproval(rs.getString(6));
				b1.setBenname(rs.getString(7));

				b.add(b1);
				System.out.println(b1.toString());
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} finally {
			conn.close();
		}
		return b;
	}

	// Delete Benficiary from user method
	public int deleteBeneficiary(String username, String accountno) {
		int i = 0;
		Connection conn = null;
		conn = JdbcConnection.getConnection();

		System.out.println("username is"+username+"acc num is"+accountno);
		String query = "DELETE FROM beneficiary WHERE username=? AND b_acc_no=?";

		try {
			PreparedStatement pst = conn.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2, accountno);
			int check = pst.executeUpdate();
			
			if (check > 0) {
				
				i = 1;
			} else {
				i = 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return i;

	}

	// View  Approval Beneficiary Details method

	public List beneficiaryApprove() throws SQLException 
	{

		List<Details> b = new ArrayList<Details>();
		Connection conn = null;
		try 
		{
			
			conn = JdbcConnection.getConnection();
			String sql = "select * from beneficiary where approval='no'";
			PreparedStatement pst = conn.prepareStatement(sql);
	
			ResultSet rs = pst.executeQuery(sql);
			while (rs.next()) 
			{

				System.out.println("Beneficiary View ");
				Details b1 = new Details();

				b1.setbId(rs.getLong(1));
				b1.setbAccNo(rs.getLong(2));
				b1.setuName(rs.getString(3));
				b1.setIfsc(rs.getString(4));
				b1.setStatus(rs.getString(6));
				b1.setbName(rs.getString(7));
			

				b.add(b1);
				System.out.println(b1.toString());
			}
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally 
		{
			conn.close();
		}
		return b;
	}
	
	//method to activate beneficiary
	public int approveBeneficiary(String bid) {
		int i = 0;
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		System.out.println("RUNNING");
		String query = "UPDATE beneficiary SET APPROVAL='yes' WHERE B_ID=?";

		try {
			System.out.println(bid);
			pst = conn.prepareStatement(query);
			pst.setString(1, bid);
			int check = pst.executeUpdate();
			System.out.println("RUNNING AGAIN");
			if (check > 0) {
				i = 1;
			} else {
				i = 0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		return i;

	}
	
	
	//METHOD TO VIEW PENDING CHEQUE APPROVALS
	
	public List pendingChequeReqquests() throws SQLException 
	{

		List<Details> b = new ArrayList<Details>();
		Connection conn = null;
		try 
		{
			
			conn = JdbcConnection.getConnection();
			String sql = "select * from CHEQUEBOOK where STATUS='REQUESTED'";
			PreparedStatement pst = conn.prepareStatement(sql);
	
			ResultSet rs = pst.executeQuery(sql);
			while (rs.next()) 
			{

				System.out.println("CHEQUEBOOK View ");
				Details b1 = new Details();

				b1.setChequeid(rs.getLong(1));
				b1.setcAccNo(rs.getString(2));
				b1.setcStatus(rs.getString(3));
			

				b.add(b1);
				System.out.println(b1.toString());
			}
		} 
		catch (SQLException e)
		{
			// TODO Auto-generated catch block
			e.printStackTrace();
		} 
		finally 
		{
			conn.close();
		}
		return b;
	}
	
	
	
	
	
	//method to approve cheque and insert transactions see line no 420
	public int approveCheque(String cid,long acNo) {
		int i = 0;
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		System.out.println("RUNNING");
		long chequeCharge=30;
		
		String query1="SELECT * FROM customer WHERE ACC_NO=?";
		
		
		try 
		{
			
			System.out.println("SEE bank user table");
			conn.setAutoCommit(false);
			pst1 = conn.prepareStatement(query1);
			pst1.setLong(1, acNo);
			ResultSet rs=pst1.executeQuery();
			while(rs.next())
			{
				
				System.out.println("Bank user query executed");
				long bal=rs.getLong(4);
				String uname=rs.getString(2);
				String cname=rs.getString(3);
			 
				if(bal-chequeCharge>=1000)
				{
					System.out.println("This is also executed");
					long nbal=bal-chequeCharge;
					System.out.println(nbal);
					System.out.println(acNo);
				
				
				
		
				
				String query9="UPDATE customer SET BALANCE=? WHERE ACC_NO=?";
				pst=conn.prepareStatement(query9);
				
				pst.setInt(1,(int) nbal);
				pst.setLong(2, acNo);
				System.out.println("AnyTHing");
				
				int q=pst.executeUpdate();
				
				System.out.println("This query is executed");
				
			/*	DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				String datesql=dateFormat.format(date);*/
				
				/*DateFormat datemonth= new SimpleDateFormat("MM");
				String mon=datemonth.format(date);*/
				
				
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				java.sql.Date datesql=new java.sql.Date(date.getYear(), date.getMonth(), date.getDay());
				
				int rand=(int) (Math.random()*1000);
				String tid=""+rand;
			
				float tamt=chequeCharge;
				Date d=new Date();
				
				//String date=""+d;
				
				String query8="INSERT INTO TRANSACTIONS VALUES(?,?,?,?,sysdate,?,?)";
				System.out.println("executed");
				pst2=conn.prepareStatement(query8);
				  pst2.setString(1,tid);
				    pst2.setString(2,uname);
				    pst2.setString(3,cname);
				    pst2.setFloat(4,chequeCharge);
				    //pst2.setString(5,date);
				    //pst2.setDate(5,datesql);
				   
				    int mon=Calendar.MONTH+2;
				    pst2.setInt(5,mon);
				    pst2.setString(6, "Cheque book charges");
				
				
				    int check=pst2.executeUpdate();
				    
				    System.out.println("Inserted into transactions");
				
				
				    String query7 = "UPDATE CHEQUEBOOK SET STATUS='APPROVED' WHERE CHKBOOKNO=?";
				
					System.out.println(cid);
					pst = conn.prepareStatement(query7);
					pst.setString(1, cid);
					int check2 = pst.executeUpdate();
					conn.commit();
					System.out.println("RUNNING AGAIN cheque");
					if (check2 > 0) {
						i = 1;
					} else {
						i = 0;
					}
				
				
				
			}
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
		

		
		return i;

	}
	
	
	
	/*public int approveCheque(String cid,long acNo) {
		int i = 0;
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		System.out.println("RUNNING");
		long chequeCharge=30;
		
		String query1="SELECT * FROM customer WHERE ACC_NO=?";
		
		
		try 
		{
			
			System.out.println("SEE bank user table");
			conn.setAutoCommit(false);
			pst1 = conn.prepareStatement(query1);
			pst1.setLong(1, acNo);
			ResultSet rs=pst1.executeQuery();
			while(rs.next())
			{
				
				System.out.println("Bank user query executed");
				long bal=rs.getLong(4);
				String uname=rs.getString(2);
				String cname=rs.getString(3);
			 
				if(bal-chequeCharge>=1000)
				{
					System.out.println("This is also executed");
					long nbal=bal-chequeCharge;
					System.out.println(nbal);
					System.out.println(acNo);
				
				
				
		
				
				String query9="UPDATE customer SET BALANCE=? WHERE ACC_NO=?";
				pst=conn.prepareStatement(query9);
				
				pst.setInt(1,(int) nbal);
				pst.setLong(2, acNo);
				System.out.println("AnyTHing");
				
				int q=pst.executeUpdate();
				
				System.out.println("This query is executed");
				
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				String datesql=dateFormat.format(date);
				
				DateFormat datemonth= new SimpleDateFormat("MM");
				String mon=datemonth.format(date);
				
				
				DateFormat dateFormat = new SimpleDateFormat("yyyy/MM/dd");
				Date date = new Date();
				java.sql.Date datesql=new java.sql.Date(date.getYear(), date.getMonth(), date.getDay());
				
				int rand=(int) (Math.random()*1000);
				String tid=""+rand;
			
				float tamt=chequeCharge;
				Date d=new Date();
				
				//String date=""+d;
				
				String query8="INSERT INTO TRANSACTIONS VALUES(?,?,?,?,to_date(?, 'yyyy-mm-dd'),?,?)";
				System.out.println("executed");
				pst2=conn.prepareStatement(query8);
				  pst2.setString(1,tid);
				    pst2.setString(2,uname);
				    pst2.setString(3,cname);
				    pst2.setFloat(4,chequeCharge);
				    //pst2.setString(5,date);
				    pst2.setDate(5,datesql);
				   
				    int mon=Calendar.MONTH+2;
				    pst2.setInt(6,mon);
				    pst2.setString(7, "Cheque book charges");
				
				
				    int check=pst2.executeUpdate();
				    
				    System.out.println("Inserted into transactions");
				
				
				    String query7 = "UPDATE CHEQUEBOOK SET STATUS='APPROVED' WHERE CHKBOOKNO=?";
				
					System.out.println(cid);
					pst = conn.prepareStatement(query7);
					pst.setString(1, cid);
					int check2 = pst.executeUpdate();
					conn.commit();
					System.out.println("RUNNING AGAIN cheque");
					if (check2 > 0) {
						i = 1;
					} else {
						i = 0;
					}
				
				
				
			}
			
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		
		

		
		return i;

	}
	
	*/
	
	//method to view pending dd requests
		public List pendingDemandDraftRequests() throws SQLException 
		{

			List<Details> b = new ArrayList<Details>();
			Connection conn = null;
			try 
			{
				
				conn = JdbcConnection.getConnection();
				String sql = "select * from DEMANDDRAFT where STATUS='Requested'";
				PreparedStatement pst = conn.prepareStatement(sql);
		
				ResultSet rs = pst.executeQuery(sql);
				while (rs.next()) 
				{

					System.out.println("dd View ");
					Details b1 = new Details();

					b1.setDdId(rs.getLong(1));
					b1.setDdaccNo(rs.getString(2));
					b1.setDdpayee(rs.getString(3));
					b1.setDdamt(rs.getLong(5));
					b1.setDdstatus(rs.getString(6));
					

					b.add(b1);
					System.out.println(b1.toString());
				}
			} 
			catch (SQLException e)
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			} 
			finally 
			{
				try 
				{
					conn.close();
				} catch (SQLException e) 
				{
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
			}
			return b;
		}
		
	
	
	
	
	
	//method to approve dd request  and add into transactions 

	public int approveDemandDraft(String ddid,long acNo,String pname,long ddamt) 
	{
		
		int i = 0;
		Connection conn = null;
		conn = JdbcConnection.getConnection();
		PreparedStatement pst = null;
		System.out.println("RUNNING");
		PreparedStatement pst1 = null;
		PreparedStatement pst2 = null;
		PreparedStatement pst3 = null;
		System.out.println("RUNNING");
		long dDCharge=30;
		
		String query1="SELECT * FROM customer WHERE ACC_NO=?";
		
		
		
			
			System.out.println("SEE bank user table");
			try {
				conn.setAutoCommit(false);
				pst1 = conn.prepareStatement(query1);
				pst1.setLong(1, acNo);
				ResultSet rs=pst1.executeQuery();
				while(rs.next())
				{
					
					System.out.println("Bank user query executed");
					long bal=rs.getLong(4);
					String uname=rs.getString(2);
					if(bal-(dDCharge+ddamt)>=1000)
					{
						System.out.println("This is also executed");
						long nbal=bal-(dDCharge+ddamt);
						System.out.println(nbal);
						System.out.println(acNo);
						String query9="UPDATE customer SET BALANCE=? WHERE ACC_NO=?";
						pst=conn.prepareStatement(query9);
					
						pst.setFloat(1, nbal);
						pst.setLong(2, acNo);
						System.out.println("AnyTHing");
						
						int q=pst.executeUpdate();
						
						System.out.println("This query is executed");
						
						int rand=(int) (Math.random()*1000);
						String tid=""+rand;
					
						float tamt=dDCharge+ddamt;
						Date d=new Date();
						String date=""+d;
						String query8="INSERT INTO TRANSACTIONS VALUES(?,?,?,?,sysdate,?,?)";
						System.out.println("executed");
						pst2=conn.prepareStatement(query8);
						pst2.setString(1,tid);
					    pst2.setString(2,uname);
					    pst2.setString(3,pname);
					    pst2.setFloat(4,tamt);
					    //pst2.setString(5,date);
					    //ps.setInt(5,new java.util.Date().getDate());
					    int mon=Calendar.MONTH+2;
					    pst2.setInt(5,mon);
					    pst2.setString(6, "DD charges");
					
					
					    int check5=pst2.executeUpdate();
					    
					    System.out.println("Inserted into transactions");


					    String query = "UPDATE DEMANDDRAFT SET STATUS='APPROVED' WHERE DDNO=?";

					    
					    	System.out.println(ddid);
					    	pst = conn.prepareStatement(query);
					    	pst.setString(1, ddid);
					    	int check = pst.executeUpdate();
					    	System.out.println("RUNNING AGAIN cheque");
					    	if (check > 0) 
					    	{
					    		i = 1;
					    	} 
					    	else 
					    	{
					    		i = 0;
					    	}
					    
					    
					}
				}
			} catch (SQLException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
			finally 
		    {
		    	try 
		    	{
		    		conn.close();
		    	} 
		    	catch (SQLException e) 
		    	{
		
		    		e.printStackTrace();
		    	}
		    }	
				    
		
		return i;
			
		
	}
			
	
	//METHOD TO ACTIVATE DEACTIVATE BENEFICIARY STATUS
	public int actdeactBeneficiary(Beneficiary b)
	{
		int i=0;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="UPDATE beneficiary SET ACTIV_STAT=? WHERE B_ID=? ";
		try {
			System.out.println(b.getActivstat());
			System.out.println(b.getBid());
			pst=conn.prepareStatement(query);
			pst.setString(1, b.getActivstat());
			pst.setString(2, b.getBid());
		
			int count=pst.executeUpdate();
			if(count >0)
			{
				i=1;
			}
			else
			{
				i=0;
			}
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
			
		return i;
	}
	
	
	
	//METHOD TO TRANSFER FUNDS    
	public int sendFunds(int index,long amt,String username,long benAccno ) 
	{
		Calendar cal = Calendar.getInstance();
		int i=0;
		long bal;
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		PreparedStatement pst1=null;
		PreparedStatement pst2=null;
		PreparedStatement pst3=null;
		try {
			conn.setAutoCommit(false);
			} catch (SQLException e1) {
			// TODO Auto-generated catch block
			e1.printStackTrace();
			}
		String query="SELECT * FROM customer WHERE USERNAME=?";
		
		try {
			pst=conn.prepareStatement(query);
			pst.setString(1, username);
			ResultSet rs= pst.executeQuery();
			if(rs.next()==true)
			{
				bal=rs.getLong(4);
				if((bal-amt)>=1000)
				{
					
					long rbal=bal-amt;
					String query1="UPDATE customer SET BALANCE=? WHERE USERNAME=?";
					long benBal=bal+amt;
					pst1=conn.prepareStatement(query1);
					pst1.setLong(1, rbal);
					pst1.setString(2, username);
					String query3="UPDATE customer SET BALANCE=? WHERE ACC_NO=?";
					pst3=conn.prepareStatement(query3);
					pst3.setLong(1,benBal);
					pst3.setLong(2, benAccno);
					int count3=pst3.executeUpdate();
					int count=pst1.executeUpdate();
					conn.commit();
					if(count>0)
					{
						
						Beneficiary b=new Beneficiary();
						List<Beneficiary> ar=viewBeneficiary(username);
						int rand=(int) (Math.random()*1000);
						String tid=""+rand;
						String benname=ar.get(index).getBenname();
						float tamt=amt;
						//Date d=new Date();
						//String date=""+d;
						String query2="INSERT INTO TRANSACTIONS VALUES(?,?,?,?,sysdate,?,?)";
						System.out.println("executed");
						pst2=conn.prepareStatement(query2);
						  pst2.setString(1,tid);
						    pst2.setString(2,username);
						    pst2.setString(3,benname);
						    pst2.setFloat(4,amt);
						    //pst2.setString(5,date);
						    //ps.setInt(5,new java.util.Date().getDate());
						    int mon=Calendar.MONTH+2;
						    pst2.setInt(5,mon);
						    pst2.setString(6, "IMPS");
						    int check=pst2.executeUpdate();
						    if(check>0)
						    {
						    	i=1;
						    }
						    else
						    {
						    	i=0;
						    }
					}
					
					
				}
			}
		} 
		catch (SQLException e) {
			// TODO Auto-generated catch block
			try {
				conn.rollback();
			} catch (SQLException e1) {
				// TODO Auto-generated catch block
				e1.printStackTrace();
			}
			e.printStackTrace();
		}
		finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				
				try {
					conn.rollback();
				} catch (SQLException e1) {
					// TODO Auto-generated catch block
					e1.printStackTrace();
				}
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		
		
		
		return i;
		
	}
	
	
	//METHOD TO VIEW TRANSATION REPORTS
	public List transactionList(String username,String startdate)
	{
		TransactionDetail t=new TransactionDetail();
		List<TransactionDetail> td=new ArrayList<TransactionDetail>();
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		System.out.println(startdate);
		//String quat1="'MAR','APR','MAY','JUN'";
		//System.out.println(quat1);
		String query="SELECT * FROM TRANSACTIONS WHERE USERNAME=? AND TO_CHAR(TRANS_DATE,'MON')=?";
		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			pst.setString(2, startdate);
			
			//pst.setString(3, enddate);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			/*	t.setTransactionId(rs.getString(1));
				t.setUserName(rs.getString(2));
				t.setBeniName(rs.getString(3));
				t.setAmount(rs.getLong(4));
				t.setTransactDate(rs.getString(5));
				t.setMonth(rs.getString(6));
				t.setTransactMode(rs.getString(7));
				td.add(t);
			*/
				TransactionDetail t1= new TransactionDetail(rs.getString(1),rs.getString(2),rs.getString(3),rs.getLong(4),rs.getString(5),rs.getString(6),rs.getString(7));
				td.add(t1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return td;
	}
	
	
	//method to view transactions between months
	
//	public List transactionMonList(String username,String startdate,String enddate)
//	{
//		TransactionDetail t=new TransactionDetail();
//		List<TransactionDetail> td=new ArrayList<TransactionDetail>();
//		Connection conn=null;
//		conn=JdbcConnection.getConnection();
//		PreparedStatement pst=null;
//		System.out.println(startdate);
//		//String quat1="'MAR','APR','MAY','JUN'";
//		//System.out.println(quat1);
//		String query="SELECT * FROM TRANSACTIONS WHERE USERNAME=? AND MONTH BETWEEN ? AND ?";
//		try {
//			pst = conn.prepareStatement(query);
//			pst.setString(1, username);
//			pst.setString(2, startdate);
//			
//			pst.setString(3, enddate);
//			ResultSet rs=pst.executeQuery();
//			while(rs.next())
//			{
//			/*	t.setTransactionId(rs.getString(1));
//				t.setUserName(rs.getString(2));
//				t.setBeniName(rs.getString(3));
//				t.setAmount(rs.getLong(4));
//				t.setTransactDate(rs.getString(5));
//				t.setMonth(rs.getString(6));
//				t.setTransactMode(rs.getString(7));
//				td.add(t);
//			*/
//				TransactionDetail t1= new TransactionDetail(rs.getString(1),rs.getString(2),rs.getString(3),rs.getLong(4),rs.getString(5),rs.getString(6),rs.getString(7));
//				td.add(t1);
//			}
//			
//		} catch (SQLException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}finally 
//		{
//			try 
//			{
//				conn.close();
//			} catch (SQLException e) 
//			{
//				// TODO Auto-generated catch block
//				e.printStackTrace();
//			}
//		}
//		
//		return td;
//	}
//	
	
	
	
	
	
	public List transactionListQuat(String username,String startdate)
	{
		TransactionDetail t=new TransactionDetail();
		List<TransactionDetail> td=new ArrayList<TransactionDetail>();
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		String query="SELECT * FROM TRANSACTIONS WHERE USERNAME=? AND TO_CHAR(TRANS_DATE,'MON') in (?,?,?)";
		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			//pst.setString(2, startdate);
			//pst.setString(3, enddate);
			if(startdate.equalsIgnoreCase("q1")){
			String mon1="JAN";
			String mon2="FEB";
			String mon3="MAR";
			
			pst.setString(2, mon1);
			pst.setString(3, mon2);
			pst.setString(4, mon3);
			
			}
			else if(startdate.equalsIgnoreCase("q2")){
				String mon1="APR";
				String mon2="MAY";
				String mon3="JUN";
				
				pst.setString(2, mon1);
				pst.setString(3, mon2);
				pst.setString(4, mon3);
				
				}
			else if(startdate.equalsIgnoreCase("q3")){
				String mon1="JUL";
				String mon2="AUG";
				String mon3="SEP";
				
				pst.setString(2, mon1);
				pst.setString(3, mon2);
				pst.setString(4, mon3);
				}
			else if(startdate.equalsIgnoreCase("q4")){
				String mon1="OCT";
				String mon2="NOV";
				String mon3="DEC";
			
				pst.setString(2, mon1);
				pst.setString(3, mon2);
				pst.setString(4, mon3);
			
				}
			
			
			
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			/*	t.setTransactionId(rs.getString(1));
				t.setUserName(rs.getString(2));
				t.setBeniName(rs.getString(3));
				t.setAmount(rs.getLong(4));
				t.setTransactDate(rs.getString(5));
				t.setMonth(rs.getString(6));
				t.setTransactMode(rs.getString(7));
				td.add(t);
			*/
				TransactionDetail t1= new TransactionDetail(rs.getString(1),rs.getString(2),rs.getString(3),rs.getLong(4),rs.getString(5),rs.getString(6),rs.getString(7));
				td.add(t1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return td;
	}
	
	
	//METHOD TO VIEW DEMAND DRAFT DETAILS SEPERATELY
	
	public List dDtransactionList(String username)
	{
		DdDetails t=new DdDetails();
		List<DdDetails> td=new ArrayList<DdDetails>();
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		//System.out.println(startdate);
	
		String query="SELECT * FROM DEMANDDRAFT WHERE ACC_NO=(SELECT ACC_NO FROM customer WHERE USERNAME=?)";
		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			//pst.setString(2, startdate);
			
			//pst.setString(3, enddate);
			ResultSet rs=pst.executeQuery();
			while(rs.next())
			{
			/*	t.setTransactionId(rs.getString(1));
				t.setUserName(rs.getString(2));
				t.setBeniName(rs.getString(3));
				t.setAmount(rs.getLong(4));
				t.setTransactDate(rs.getString(5));
				t.setMonth(rs.getString(6));
				t.setTransactMode(rs.getString(7));
				td.add(t);
			*/
				DdDetails t1= new DdDetails(rs.getInt(1),rs.getLong(2),rs.getString(3),rs.getDate(4),rs.getLong(5),rs.getString(6));
				td.add(t1);
			}
			
		} catch (SQLException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}finally 
		{
			try 
			{
				conn.close();
			} catch (SQLException e) 
			{
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
		}
		
		return td;
	}
	
//	METHOD TO VIEW CHEQUE DETAILS
	public List<ChequeDetails> chequeTransactionList(String username)
	{
		
		List<ChequeDetails> td=new ArrayList<ChequeDetails>();
		Connection conn=null;
		conn=JdbcConnection.getConnection();
		PreparedStatement pst=null;
		//System.out.println(startdate);
	
		String query="SELECT * FROM CHEQUEBOOK WHERE ACC_NO=(SELECT ACC_NO FROM customer WHERE USERNAME=?)";
		try {
			pst = conn.prepareStatement(query);
			pst.setString(1, username);
			//pst.setString(2, startdate);
			
			//pst.setString(3, enddate);
			ResultSet rs=pst.executeQuery();
			int i=0;
			while(rs.next())
			{
				ChequeDetails t=new ChequeDetails();
				t.setChkBookNo(rs.getInt(1));
				t.setAccNo(rs.getString(2));
				t.setDate(rs.getDate(3));
				t.setStatus(rs.getString(4));
			/*	t.setTransactionId(rs.getString(1));
				t.setUserName(rs.getString(2));
				t.setBeniName(rs.getString(3));
				t.setAmount(rs.getLong(4));
				t.setTransactDate(rs.getString(5));
				t.setMonth(rs.getString(6));
				t.setTransactMode(rs.getString(7));
				td.add(t);
			
				System.out.println("DATA GOING IN LIST");
				ChequeDetails t1= new ChequeDetails(rs.getInt(1),rs.getString(2),rs.getString(3),rs.getDate(4));
				*/
				
				td.add(t);
		
			}
			
			
		} catch (SQLException e) {
		
			e.printStackTrace();
		}
		
		
		finally 
		{
			try 
			{
				
				conn.close();
			} catch (SQLException e) 
			{
			
				e.printStackTrace();
			}
		}
		return td;
		
		
	}
	
	
	
}

	
	
