

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pb.dao.LoginDao;
import com.pb.dao.LoginDaoImpl;

/**
 * Servlet implementation class RedirectServlet
 */
public class RedirectServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public RedirectServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		PrintWriter out=response.getWriter();
		LoginDao ldao=new LoginDaoImpl();
		HttpSession session =request.getSession(false);
		String m_dbname = (String) request.getSession().getAttribute("a_username");
		String m_dbpassword = (String) request.getSession().getAttribute("a_password");
		System.out.println(m_dbname);
		System.out.println(m_dbpassword);
		String role = ldao.validate(m_dbname, m_dbpassword);
		//System.out.println(role);

		if (role.equals("admin")) {
			System.out.println("going to admin page");
		
			
			RequestDispatcher rd = request
					.getRequestDispatcher("AdminPage.jsp");
			rd.forward(request, response);

			// out.println("Admin logged in ");
		} else if (role.equals("user")) {

			
			out.println("User logged in ");

			RequestDispatcher rd = request.getRequestDispatcher("UserPage.jsp");
			rd.forward(request, response);

		}
	}

}
