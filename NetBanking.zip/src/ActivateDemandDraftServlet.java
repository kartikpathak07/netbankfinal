

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import com.pb.dao.BeneficiaryDaoImpl;
import com.pb.dto.Details;

/**
 * Servlet implementation class ActivateDemandDraftServlet
 */
public class ActivateDemandDraftServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public ActivateDemandDraftServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("In activate ddservlet");
		HttpSession session = request.getSession();
		String uname = (String) session.getAttribute("a_username");
		
		BeneficiaryDaoImpl bdao = new BeneficiaryDaoImpl();
		PrintWriter out = response.getWriter();
		response.setContentType("text/html");
		BeneficiaryDaoImpl bdao1 = new BeneficiaryDaoImpl();
		Details dt= new Details();
		String ddid=request.getParameter("dDId");
		long ddamt=Long.parseLong(request.getParameter("ddAmt"));
		long ddAcno=Long.parseLong(request.getParameter("ddAcNo"));
		String ddPay=request.getParameter("ddPay");
		//System.out.println(id);
		
		int check=bdao1.approveDemandDraft(ddid,ddAcno,ddPay,ddamt);
		if(check==1)
		{
			System.out.println("CHEQUE APPROVED");
			RequestDispatcher rd=request.getRequestDispatcher("AdminPage.jsp");
			rd.forward(request, response);
		}
		else
		{
			System.out.println("NOT UPDATED");
		}
		
	
	}
	}


