

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.pb.dao.LoginDao;
import com.pb.dao.LoginDaoImpl;

/**
 * Servlet implementation class AdminPageServlet
 */
public class AdminPageServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
       
    /**
     * @see HttpServlet#HttpServlet()
     */
    public AdminPageServlet() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException 
	{
		System.out.println("YOU ARE IN ADMIN PAGE SERVLET CHANGE PASSWORD METHOD");
		String m_updatepassword=request.getParameter("changePassword");
		//System.out.println(m_updatepassword);
		if(m_updatepassword.equals("Change Your Password"))
		{
			System.out.println(" IN CHANGE PASSWORD .JSP");
			RequestDispatcher rd = request.getRequestDispatcher("changePassword.jsp");
			rd.forward(request, response);
		}
		
	}

}
